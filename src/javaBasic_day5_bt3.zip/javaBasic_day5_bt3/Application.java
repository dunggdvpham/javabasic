package javaBasic_day5_bt3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> danhSach = new ArrayList<String>();
		Scanner sc = new Scanner(System.in);
	
		while(true) {
			System.out.println("Chọn 1 trong các lựa chọn:");
			System.out.println("1. Nhập thông tin nhân viên. \n"
					+          "2. Xem danh sách nhân viên đã nhập. \n"
					+          "3. Thoát.");
			int initOption = sc.nextInt();
		sc.nextLine();
			switch (initOption) {
			case 1:
				System.out.println("Bạn muốn nhập thông tin của Developer, tester hay BA?");
				String option = sc.nextLine().trim().toLowerCase();
				switch (option) {
				case "developer":
					Developer dev1 = new Developer();
					String inforDev = dev1.fillInfo();
					danhSach.add(inforDev);
					dev1.printInfo();
					break;
				case "tester" :
					Tester test1 = new Tester();
					String inforTest = test1.fillInfo();
					danhSach.add(inforTest);
					test1.printInfo();
					break;
				case "ba" :
					BusinessAnalyst ba1 = new BusinessAnalyst();
					String inforBA = ba1.fillInfo();
					danhSach.add(inforBA);
					ba1.printInfo();
					break;
				default:
					System.out.println("Không tìm thấy vai trò phù hợp, kết thúc chương trình!");
					break;
				}
				break;
			case 2: 
				for (String item : danhSach) {
					System.out.println(item);
				}
				break;
			case 3:
				sc.close();
				return;
			default:
				System.out.println("Lựa chọn không hợp lệ. Vui lòng thử lại.");
			}
		}
	}
}
//			if(initOption == 1) {
//				System.out.println("Bạn muốn nhập thông tin của Developer, tester hay BA?");
//				String option = sc.nextLine().trim().toLowerCase();
//				if(option.equals("developer")) {
//					
//				}else if (option.equals("tester")) {
//					Tester test1 = new Tester();
//					String inforTest = test1.fillInfo();
//					danhSach.add(inforTest);
//					test1.printInfo();
//				}else if(option.equals("ba")) {
//					BusinessAnalyst ba1 = new BusinessAnalyst();
//					String inforBA = ba1.fillInfo();
//					danhSach.add(inforBA);
//					ba1.printInfo();
//				} else {
//					
//			} if (initOption == 2) {
//				
//				System.out.println(danhSach);
//			} if (initOption == 3) {
//				break;
//			}
//		}
//		
//		System.out.println("Bạn muốn nhập thông tin của Developer, tester hay BA?");
//		String option = sc.nextLine();
//		switch (option.trim().toLowerCase()) {
//		case "developer":
//			Developer dev1 = new Developer();
//			dev1.fillInfo();
//			dev1.printInfo();
//			break;
//		case "tester":
//			Tester test1 = new Tester();
//			test1.fillInfo();
//			test1.printInfo();
//			break;
//		case "ba":
//			BusinessAnalyst ba1 = new BusinessAnalyst();
//			ba1.fillInfo();
//			ba1.printInfo();
//			break;
//		default:
//			System.out.println("Không tìm thấy vai trò phù hợp, kết thúc chương trình!");
//			break;
//		}
		
//		sc.close();
//	}
//
//}
