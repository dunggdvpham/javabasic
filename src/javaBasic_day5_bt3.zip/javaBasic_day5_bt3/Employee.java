package javaBasic_day5_bt3;

public abstract class Employee {
	protected String name;
	protected int age;
	protected double expYear;
	
	public abstract String fillInfo();
	public abstract void printInfo();
	
}
